import { createRoute } from 'react-dom/client'
import { useState } from 'react'
import { BrowserRouter, Routes, Route, Link, Form } from 'react-router-dom'
import './App.css'
import Header from './Header'
import Roulette from './Ruletka'
import Home from './pages/Home'
import Cart from './pages/Cart'
import Products from './pages/Produkty'
import 'bootstrap/dist/css/bootstrap.css'
/*         <nav className='App-nav'>
        <Link to={'/ruletka'}>Ruletka </Link>       
        </nav>
 */ 
function App() {
  const [cart, setCart] = useState([])

  const addToCart = (item) => {
    if (!cart.find((p) => p.id === item.id)) {
      setCart([...cart, item]);
    }
  };

  const removeFromCart = (id) => {
    setCart(cart.filter((p) => p.id !== id))
  };

  return (
    <>
    <BrowserRouter>
      <Header />
      <div className="container mt-4">
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/produkty" element={<Products addToCart={addToCart} />} />
          <Route path="/cart" element={<Cart cart={cart} removeFromCart={removeFromCart} />} />
        </Routes>
      </div>
    </BrowserRouter>
    </>
  )
}

export default App
