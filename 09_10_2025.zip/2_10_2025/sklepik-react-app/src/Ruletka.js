import React, { useState } from 'react'
import './App.css'
import { Wheel } from 'react-custom-roulette'

const data = [
    { option: '0',style:{backgroundColor:'green'}},
    { option: '26' },
    { option: '3' },
    { option: '35' },
    { option: '12' },
    { option: '28' },
    { option: '7' },
    { option: '29' },
    { option: '18' },
    { option: '22' },
    { option: '9' },
    { option: '31' },
    { option: '14' },
    { option: '20' },
    { option: '1' },
    { option: '33' },
    { option: '16' },
    { option: '24' },
    { option: '5' },
    { option: '10' },
    { option: '23' },
    { option: '8' },
    { option: '30' },
    { option: '11' },
    { option: '36' },
    { option: '13' },
    { option: '27' },
    { option: '6' },    
    { option: '34' },
    { option: '17' },
    { option: '25' },
    { option: '2' },
    { option: '21' },
    { option: '4' },
    { option: '19' },
    { option: '15' },
    { option: '32' },
]

export default () => {
    const [mustSpin, setMustSpin] = useState(false);
    const [prizeNumber, setPrizeNumber] = useState(0);

    const handleSpinClick = () => {
        const newPrizeNumber = Math.floor(Math.random() * data.length)
        setPrizeNumber(newPrizeNumber)
        setMustSpin(true)
    }

    return (
        <div className='Wheel'>
            <section className='Wheel-section'>
                <Wheel
                    mustStartSpinning={mustSpin}
                    prizeNumber={prizeNumber}
                    data={data}
                    backgroundColors={['black', 'red']}
                    textColors={['white', 'white']}
                    innerRadius={20}
                    perpendicularText={true}
                    radiusLineColor='gold'
                    radiusLineWidth={2.2}
                    textDistance={75}
                    spinDuration={0.5}

                    onStopSpinning={() => {
                        setMustSpin(false);
                    }}
                />
                <section className='Wheel-section-button'>
                    <button onClick={handleSpinClick}>SPIN</button>
                </section>
            </section>
        </div>
    )
}