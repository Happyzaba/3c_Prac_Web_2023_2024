import React from "react"
import {Button} from 'bootstrap'
function Cart(cart, removeFromCart) {
    return (
    <div>
      <h3>Koszyk</h3>
      {cart.length === 0 ? (
        <p>Brak produktów w koszyku.</p>
      ) : (
        <ul className="list-group">
          {cart.map(p => (
            <li key={p.id} className="list-group-item d-flex justify-content-between">
              {p.name} – {p.price} zł
              <Button size="sm" onClick={() => removeFromCart(p.id)}>Usuń</Button>
            </li>
          ))}
        </ul>
      )}
    </div>
  )
}
export default Cart