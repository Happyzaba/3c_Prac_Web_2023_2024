export default function Home() {
     return (
    <div className="text-center">
      <h2>Witamy w sklepie Lidlonka!</h2>
      <p>Wybierz produkty, dodaj do koszyka i złóż zamówienie</p>
    </div>
  )
}