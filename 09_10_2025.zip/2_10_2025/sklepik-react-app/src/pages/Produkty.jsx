import {useState} from 'react'
import { products } from './produktydata'
import { Button, Form  } from 'react'

function Products({ addToCart }) {
  const [filter, setFilter] = useState("");

  const categories = [...new Set(products.map(p => p.category))];
  const filtered = filter ? products.filter(p => p.category === filter) : products;

  return (
    <div>
      <h3>Lista produktów</h3>
      <Form>
        {categories.map(cat => (
          <Form.Check
            key={cat}
            inline
            type="radio"
            name="category"
            label={cat}
            onChange={() => setFilter(cat)}
          />
        ))}
        <Form.Check
          inline
          type="radio"
          name="category"
          label="Wszystkie"
          onChange={() => setFilter("")}
        />
      </Form>
      <div className="row mt-3">
        {filtered.map(p => (
          <div key={p.id} className="col-md-3 mb-3">
            <div className="card p-3 text-center">
              <h5>{p.name}</h5>
              <p>{p.category}</p>
              <p>{p.price} zł</p>
              <Button onClick={() => addToCart(p)}>Dodaj do koszyka</Button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

export default Products;