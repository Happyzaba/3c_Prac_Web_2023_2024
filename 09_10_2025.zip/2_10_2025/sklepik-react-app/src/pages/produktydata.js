export const products = [
    {id:1, name:"Tyskie", category: "Piwo", price:2.5},
    {id:2, name:"Shogun", category: "Wino", price:1.5},
    {id:3, name:"Bułka", category: "Pieczywo", price:3},
    {id:4, name:"Sztumbras", category: "Wodka", price:5}
];