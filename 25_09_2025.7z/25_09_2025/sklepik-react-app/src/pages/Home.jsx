import React from "react";
export default function Home(){
    return(
        <div>
            <h2>Witaj w sklepie Lidlronka</h2>
        </div>
    )
}