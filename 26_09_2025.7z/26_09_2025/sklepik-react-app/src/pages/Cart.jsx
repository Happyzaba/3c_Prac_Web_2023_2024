import React from "react";
export default function Cart(){
    return(
        <div>
            <h2>To jest koszyk</h2>
        </div>
    )
}