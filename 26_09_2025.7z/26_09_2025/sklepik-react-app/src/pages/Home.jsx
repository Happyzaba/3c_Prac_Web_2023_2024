import React from "react";
export default function Home() {
    return (
        <div className="Home">
            <section>
                <h1>
                    siema
                </h1>
            </section>
        </div>
    )
}