import { createRoute } from 'react-dom/client'
import { BrowserRouter, Routes, Route, Link, Form } from 'react-router-dom'
import './App.css'
import Roulette from './Ruletka'
import Home from './pages/Home'
import Cart from './pages/Cart'
import Produkty from './pages/Produkty'
import Detale from './pages/Detale'
import 'bootstrap/dist/css/bootstrap.css'
/*         <nav className='App-nav'>
        <Link to={'/ruletka'}>Ruletka </Link>       
        </nav>
 */ 
function App() {
  return ( 
    <BrowserRouter>
      <div className='App'>
        <header className='App-header'>
          <Link to={"/"} className="App-header-Link">Lidlronka </Link>
          <Link to={"/produkty"} className="App-header-Link">Produkty</Link>
          <Link to={'/cart'} className="App-header-Link"><img src="koszyk.jpg" className="App-header-img"></img> </Link>
        </header>
        <section className='App-section'>
          <Routes>
            <Route path='/' element={<Home />} />
            <Route path='/cart' element={<Cart />} />
            <Route path='/ruletka' element={<Roulette />} />
            <Route path='/produkty' element={<Produkty />} />
            <Route path='*' element={<h1>404 - Nie znaleziono</h1>} />
          </Routes>
        </section>
        <footer className='App-footer'>
          <h6 className='App-footer-text'>
            Jest to bardzo tani sklep
          </h6>
          <i className='App-footer-text'>
            Tańszy niż lidl i biedronka razem
          </i>
        </footer>
      </div>
    </BrowserRouter>
  );
}

export default App;
