export default function Cart(){
    return(
        <div className="Cart">
            <section className="Cart-section">
                <h1>na razie pusty</h1>
            </section>
        </div>
    )
}