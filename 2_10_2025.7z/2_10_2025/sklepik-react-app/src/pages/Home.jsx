export default function Home() {
    return (
        <div className="Home">
            <section className="Home-section">
                <h1>
                    To stronga głowna tego pieknego sklepu
                </h1>
            </section>
        </div>
    )
}