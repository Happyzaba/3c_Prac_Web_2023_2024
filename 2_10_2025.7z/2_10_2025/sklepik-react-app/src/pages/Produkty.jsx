export default function Produkty() {
    return (
        <div className="Produkty">
            <section className="Produkty-section">
                <p className="Produkty-section-p">Banan<button>dodaj</button> </p>
            </section>
        </div>
    )
}